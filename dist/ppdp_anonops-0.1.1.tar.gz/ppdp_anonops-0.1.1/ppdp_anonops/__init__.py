from .addition import Addition
from .condensation import Condensation
from .cryptography import Cryptography
from .generalization import Generalization
from .substitution import Substitution
from .suppression import Suppression
from .swapping import Swapping
from.anonymizationOperationInterface import AnonymizationOperationInterface
